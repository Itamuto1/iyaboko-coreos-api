# Iyaboko CoreOS API

Minimal FastAPI backend for Iyaboko CoreOS.

## Local run
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Health check
- `/`
- `/health`
- `/docs`
