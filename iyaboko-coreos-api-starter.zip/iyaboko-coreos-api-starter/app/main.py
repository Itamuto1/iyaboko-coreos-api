from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Iyaboko CoreOS API",
    version="0.1.0",
    description="Backend API for Iyaboko CoreOS"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://iyaboko.com",
        "https://www.iyaboko.com",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {
        "message": "Iyaboko CoreOS API is running",
        "docs": "/docs",
        "health": "/health"
    }

@app.get("/health")
def health():
    return {
        "ok": True,
        "service": "Iyaboko CoreOS API",
        "status": "running"
    }
